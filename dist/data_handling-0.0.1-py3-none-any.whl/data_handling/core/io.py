"""Dataframe IO with registry-based extensibility."""

from __future__ import annotations

import os
import posixpath
from collections.abc import Callable
from typing import Any

import fsspec
import pandas as pd
from fsspec.core import url_to_fs

from data_handling.core.errors import (
    IOConfigError,
    IOReadError,
    IOWriteError,
    OptionalDependencyError,
    UnsupportedFormatError,
)
from data_handling.schema.types import FileFormat, IOConfig

Reader = Callable[[IOConfig], pd.DataFrame]
Writer = Callable[[pd.DataFrame, IOConfig], None]

_READERS: dict[FileFormat, Reader] = {}
_WRITERS: dict[FileFormat, Writer] = {}


def register_reader(file_format: FileFormat, reader: Reader) -> None:
    """Register a reader for a file format."""
    _READERS[file_format] = reader


def register_writer(file_format: FileFormat, writer: Writer) -> None:
    """Register a writer for a file format."""
    _WRITERS[file_format] = writer


def _ensure_parent_dir(path: str, storage_options: dict[str, Any]) -> None:
    fs, fs_path = url_to_fs(path, **storage_options)

    if fs.protocol in {"file", "local"}:
        parent = os.path.dirname(fs_path)
    else:
        parent = posixpath.dirname(fs_path)

    if parent:
        fs.makedirs(parent, exist_ok=True)


def _read_csv(cfg: IOConfig) -> pd.DataFrame:
    return pd.read_csv(cfg.path, storage_options=cfg.storage_options, **cfg.options)


def _write_csv(df: pd.DataFrame, cfg: IOConfig) -> None:
    _ensure_parent_dir(cfg.path, cfg.storage_options)
    df.to_csv(cfg.path, index=False, storage_options=cfg.storage_options, **cfg.options)


def _read_parquet(cfg: IOConfig) -> pd.DataFrame:
    return pd.read_parquet(cfg.path, storage_options=cfg.storage_options, **cfg.options)


def _write_parquet(df: pd.DataFrame, cfg: IOConfig) -> None:
    _ensure_parent_dir(cfg.path, cfg.storage_options)
    df.to_parquet(cfg.path, storage_options=cfg.storage_options, **cfg.options)


def _read_json(cfg: IOConfig) -> pd.DataFrame:
    with fsspec.open(cfg.path, "rb", **cfg.storage_options) as handle:
        return pd.read_json(handle, **cfg.options)


def _write_json(df: pd.DataFrame, cfg: IOConfig) -> None:
    _ensure_parent_dir(cfg.path, cfg.storage_options)
    with fsspec.open(cfg.path, "w", encoding="utf-8", **cfg.storage_options) as handle:
        df.to_json(handle, **cfg.options)


def _read_excel(cfg: IOConfig) -> pd.DataFrame:
    with fsspec.open(cfg.path, "rb", **cfg.storage_options) as handle:
        return pd.read_excel(handle, **cfg.options)


def _write_excel(df: pd.DataFrame, cfg: IOConfig) -> None:
    _ensure_parent_dir(cfg.path, cfg.storage_options)
    with fsspec.open(cfg.path, "wb", **cfg.storage_options) as handle:
        df.to_excel(handle, index=False, **cfg.options)


def _read_feather(cfg: IOConfig) -> pd.DataFrame:
    return pd.read_feather(cfg.path, storage_options=cfg.storage_options, **cfg.options)


def _write_feather(df: pd.DataFrame, cfg: IOConfig) -> None:
    _ensure_parent_dir(cfg.path, cfg.storage_options)
    df.to_feather(cfg.path, **cfg.options)


def _read_orc(cfg: IOConfig) -> pd.DataFrame:
    return pd.read_orc(cfg.path, storage_options=cfg.storage_options, **cfg.options)


def _write_orc(df: pd.DataFrame, cfg: IOConfig) -> None:
    _ensure_parent_dir(cfg.path, cfg.storage_options)
    df.to_orc(cfg.path, **cfg.options)


def _read_pickle(cfg: IOConfig) -> pd.DataFrame:
    return pd.read_pickle(cfg.path, storage_options=cfg.storage_options, **cfg.options)


def _write_pickle(df: pd.DataFrame, cfg: IOConfig) -> None:
    _ensure_parent_dir(cfg.path, cfg.storage_options)
    df.to_pickle(cfg.path, **cfg.options)


def _read_sql(cfg: IOConfig) -> pd.DataFrame:
    from sqlalchemy import create_engine

    query = cfg.options.get("query")
    table = cfg.options.get("table")

    if not query and not table:
        msg = "SQL IO requires options.query or options.table"
        raise IOConfigError(message=msg, path=cfg.path, file_format=cfg.format.value)

    engine = create_engine(cfg.path)
    if query:
        return pd.read_sql_query(query, engine, **cfg.options.get("read_options", {}))
    return pd.read_sql_table(table, engine, **cfg.options.get("read_options", {}))


def _write_sql(df: pd.DataFrame, cfg: IOConfig) -> None:
    from sqlalchemy import create_engine

    table = cfg.options.get("table")
    if not table:
        msg = "SQL IO requires options.table"
        raise IOConfigError(message=msg, path=cfg.path, file_format=cfg.format.value)

    if_exists = cfg.options.get("if_exists", "replace")
    index = cfg.options.get("index", False)

    engine = create_engine(cfg.path)
    df.to_sql(table, engine, if_exists=if_exists, index=index, **cfg.options.get("write_options", {}))


def _read_delta(cfg: IOConfig) -> pd.DataFrame:
    try:
        from deltalake import DeltaTable
    except ImportError as exc:
        raise OptionalDependencyError(dependency="deltalake", feature="Delta IO") from exc

    table = DeltaTable(cfg.path, storage_options=cfg.storage_options)
    return table.to_pandas()


def _write_delta(df: pd.DataFrame, cfg: IOConfig) -> None:
    try:
        from deltalake.writer import write_deltalake
    except ImportError as exc:
        raise OptionalDependencyError(dependency="deltalake", feature="Delta IO") from exc

    write_deltalake(cfg.path, df, storage_options=cfg.storage_options, **cfg.options)


register_reader(FileFormat.CSV, _read_csv)
register_writer(FileFormat.CSV, _write_csv)
register_reader(FileFormat.PARQUET, _read_parquet)
register_writer(FileFormat.PARQUET, _write_parquet)
register_reader(FileFormat.JSON, _read_json)
register_writer(FileFormat.JSON, _write_json)
register_reader(FileFormat.EXCEL, _read_excel)
register_writer(FileFormat.EXCEL, _write_excel)
register_reader(FileFormat.FEATHER, _read_feather)
register_writer(FileFormat.FEATHER, _write_feather)
register_reader(FileFormat.ORC, _read_orc)
register_writer(FileFormat.ORC, _write_orc)
register_reader(FileFormat.PICKLE, _read_pickle)
register_writer(FileFormat.PICKLE, _write_pickle)
register_reader(FileFormat.SQL, _read_sql)
register_writer(FileFormat.SQL, _write_sql)
register_reader(FileFormat.DELTA, _read_delta)
register_writer(FileFormat.DELTA, _write_delta)


def read_dataframe(cfg: IOConfig) -> pd.DataFrame:
    """Read a dataframe using the configured reader."""
    reader = _READERS.get(cfg.format)
    if not reader:
        msg = "No reader registered for format"
        raise UnsupportedFormatError(message=msg, path=cfg.path, file_format=cfg.format.value)
    try:
        return reader(cfg)
    except Exception as exc:
        msg = "Failed to read dataset"
        raise IOReadError(message=msg, path=cfg.path, file_format=cfg.format.value) from exc


def write_dataframe(df: pd.DataFrame, cfg: IOConfig) -> None:
    """Write a dataframe using the configured writer."""
    writer = _WRITERS.get(cfg.format)
    if not writer:
        msg = "No writer registered for format"
        raise UnsupportedFormatError(message=msg, path=cfg.path, file_format=cfg.format.value)
    try:
        writer(df, cfg)
    except Exception as exc:
        msg = "Failed to write dataset"
        raise IOWriteError(message=msg, path=cfg.path, file_format=cfg.format.value) from exc
