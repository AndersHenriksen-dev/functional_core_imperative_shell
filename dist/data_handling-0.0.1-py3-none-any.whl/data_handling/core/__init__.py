"""Core infrastructure for orchestration, IO, and validation."""

from data_handling.core.errors import (
    ConfigValidationError,
    DataHandlingError,
    DomainExecutionError,
    DomainInterfaceError,
    DomainNotFoundError,
    IOConfigError,
    IOErrorBase,
    IOReadError,
    IOWriteError,
    OptionalDependencyError,
    SchemaValidationError,
    UnsupportedFormatError,
)
from data_handling.core.io import read_dataframe, register_reader, register_writer, write_dataframe
from data_handling.core.logging import configure_logging, get_domain_logger, get_logger
from data_handling.core.orchestrator import run_domains
from data_handling.core.validation import load_and_validate_config

__all__ = [
    "ConfigValidationError",
    "DataHandlingError",
    "DomainExecutionError",
    "DomainInterfaceError",
    "DomainNotFoundError",
    "IOConfigError",
    "IOErrorBase",
    "IOReadError",
    "IOWriteError",
    "OptionalDependencyError",
    "SchemaValidationError",
    "UnsupportedFormatError",
    "configure_logging",
    "get_domain_logger",
    "get_logger",
    "load_and_validate_config",
    "read_dataframe",
    "register_reader",
    "register_writer",
    "run_domains",
    "write_dataframe",
]
