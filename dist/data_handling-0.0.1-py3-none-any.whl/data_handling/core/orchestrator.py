"""Orchestration for running domain pipelines."""

from __future__ import annotations

import importlib
from collections.abc import Iterable

from data_handling.core.errors import (
    DataHandlingError,
    DomainExecutionError,
    DomainInterfaceError,
    DomainNotFoundError,
)
from data_handling.core.logging import get_domain_logger
from data_handling.schema.types import DomainConfig, GlobalConfig


def _load_domain_runner(domain_name: str):
    try:
        module = importlib.import_module(f"data_handling.domains.{domain_name}.pipeline")
    except ModuleNotFoundError as exc:
        msg = "Domain pipeline module not found"
        raise DomainNotFoundError(domain=domain_name, message=msg) from exc

    if not hasattr(module, "run"):
        msg = "Domain module is missing required 'run' function"
        raise DomainInterfaceError(domain=domain_name, message=msg)
    return module.run


def _iter_selected_domains(cfg: GlobalConfig) -> Iterable[tuple[str, DomainConfig]]:
    selected = cfg.domains.items()

    if cfg.active_domains:
        selected = [(name, domain) for name, domain in selected if name in cfg.active_domains]

    if cfg.active_tags:
        selected = [(name, domain) for name, domain in selected if set(cfg.active_tags).intersection(domain.tags)]

    return selected


def run_domains(cfg: GlobalConfig) -> None:
    """Run selected domains based on config filters."""
    for domain_name, domain_cfg in _iter_selected_domains(cfg):
        logger = get_domain_logger("orchestrator", domain_name)

        if not domain_cfg.enabled:
            logger.info("Skipping domain (disabled)")
            continue

        logger.info("Starting domain")
        runner = _load_domain_runner(domain_name)
        try:
            runner(domain_cfg)
        except DataHandlingError:
            raise
        except Exception as exc:
            msg = "Domain execution failed"
            raise DomainExecutionError(domain=domain_name, message=msg) from exc
        logger.info("Completed domain")
