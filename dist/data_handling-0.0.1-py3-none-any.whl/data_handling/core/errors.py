"""Custom exceptions for data_handling."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any


class DataHandlingError(Exception):
    """Base exception for data_handling errors."""


@dataclass
class ConfigValidationError(DataHandlingError):
    """Raised when the Hydra configuration fails validation."""

    message: str
    details: Any | None = None

    def __str__(self) -> str:
        if self.details is None:
            return self.message
        return f"{self.message} Details: {self.details}"


@dataclass
class SchemaValidationError(DataHandlingError):
    """Raised when a dataset fails schema validation."""

    message: str
    dataset: str | None = None

    def __str__(self) -> str:
        if self.dataset:
            return f"{self.message} Dataset: {self.dataset}"
        return self.message


@dataclass
class DomainError(DataHandlingError):
    """Base exception for domain-related errors."""

    domain: str
    message: str

    def __str__(self) -> str:
        return f"{self.domain}: {self.message}"


class DomainNotFoundError(DomainError):
    """Raised when a domain module cannot be imported."""


class DomainInterfaceError(DomainError):
    """Raised when a domain does not expose the expected interface."""


class DomainExecutionError(DomainError):
    """Raised when a domain fails during execution."""


@dataclass
class IOErrorBase(DataHandlingError):
    """Base exception for IO failures."""

    message: str
    path: str | None = None
    file_format: str | None = None

    def __str__(self) -> str:
        parts = [self.message]
        if self.path:
            parts.append(f"path={self.path}")
        if self.file_format:
            parts.append(f"format={self.file_format}")
        return " | ".join(parts)


class IOConfigError(IOErrorBase):
    """Raised when IO configuration is invalid."""


class IOReadError(IOErrorBase):
    """Raised when an IO read fails."""


class IOWriteError(IOErrorBase):
    """Raised when an IO write fails."""


class UnsupportedFormatError(IOErrorBase):
    """Raised when a file format is not supported or registered."""


@dataclass
class OptionalDependencyError(DataHandlingError):
    """Raised when an optional dependency is required but missing."""

    dependency: str
    feature: str

    def __str__(self) -> str:
        return f"Missing optional dependency '{self.dependency}' for {self.feature}."
