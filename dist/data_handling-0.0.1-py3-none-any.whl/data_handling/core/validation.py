"""Hydra config validation and conversion."""

from __future__ import annotations

from omegaconf import DictConfig, OmegaConf
from pydantic import ValidationError

from data_handling.core.errors import ConfigValidationError
from data_handling.schema.config_models import GlobalConfigModel
from data_handling.schema.types import GlobalConfig


def load_and_validate_config(cfg: DictConfig) -> GlobalConfig:
    """Convert Hydra config to validated dataclasses."""
    raw = OmegaConf.to_container(cfg, resolve=True)
    try:
        model = GlobalConfigModel.model_validate(raw)
    except ValidationError as exc:
        raise ConfigValidationError("Configuration validation failed.", details=exc.errors()) from exc
    return model.to_dataclass()
