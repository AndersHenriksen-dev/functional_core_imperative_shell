"""Hydra entry point for orchestrating domains."""

from __future__ import annotations

import hydra
from omegaconf import DictConfig

from data_handling.core.errors import DataHandlingError
from data_handling.core.logging import configure_logging, get_logger
from data_handling.core.orchestrator import run_domains
from data_handling.core.validation import load_and_validate_config


@hydra.main(version_base=None, config_path="pkg://data_handling.configs", config_name="config")
def main(cfg: DictConfig) -> None:
    app_cfg = load_and_validate_config(cfg)
    configure_logging(app_cfg.logging)

    logger = get_logger("orchestrator")
    logger.info("Starting orchestration")

    try:
        run_domains(app_cfg)
    except DataHandlingError as exc:
        logger.error("Orchestration failed: %s", exc, exc_info=True)
        raise


if __name__ == "__main__":
    main()
