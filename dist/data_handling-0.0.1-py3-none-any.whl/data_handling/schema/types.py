"""Dataclass-based runtime configuration types."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any


class FileFormat(str, Enum):
    """Supported file formats."""

    CSV = "csv"
    PARQUET = "parquet"
    JSON = "json"
    EXCEL = "excel"
    FEATHER = "feather"
    ORC = "orc"
    PICKLE = "pickle"
    SQL = "sql"
    DELTA = "delta"


@dataclass(frozen=True)
class IOConfig:
    """IO configuration for a single dataframe."""

    path: str
    format: FileFormat
    options: dict[str, Any] = field(default_factory=dict)
    storage_options: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class DomainConfig:
    """Configuration for a domain pipeline."""

    name: str
    enabled: bool = True
    tags: list[str] = field(default_factory=list)
    inputs: dict[str, IOConfig] = field(default_factory=dict)
    outputs: dict[str, IOConfig] = field(default_factory=dict)
    params: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class LoggingConfig:
    """Logging configuration."""

    level: str = "INFO"
    log_dir: str = "logs"
    to_console: bool = True
    to_file: bool = True


@dataclass(frozen=True)
class GlobalConfig:
    """Top-level application configuration."""

    env: str
    logging: LoggingConfig
    active_domains: list[str] = field(default_factory=list)
    active_tags: list[str] = field(default_factory=list)
    domains: dict[str, DomainConfig] = field(default_factory=dict)
