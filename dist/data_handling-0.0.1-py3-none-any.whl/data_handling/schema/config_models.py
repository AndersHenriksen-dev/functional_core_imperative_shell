"""Pydantic models for configuration validation."""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, ConfigDict, Field

from data_handling.schema.types import DomainConfig, FileFormat, GlobalConfig, IOConfig, LoggingConfig


class IOConfigModel(BaseModel):
    """Pydantic model for IO config validation."""

    model_config = ConfigDict(extra="forbid")

    path: str
    format: FileFormat
    options: dict[str, Any] = Field(default_factory=dict)
    storage_options: dict[str, Any] = Field(default_factory=dict)

    def to_dataclass(self) -> IOConfig:
        return IOConfig(
            path=self.path,
            format=self.format,
            options=dict(self.options),
            storage_options=dict(self.storage_options),
        )


class DomainConfigModel(BaseModel):
    """Pydantic model for domain validation."""

    model_config = ConfigDict(extra="forbid")

    name: str
    enabled: bool = True
    tags: list[str] = Field(default_factory=list)
    inputs: dict[str, IOConfigModel] = Field(default_factory=dict)
    outputs: dict[str, IOConfigModel] = Field(default_factory=dict)
    params: dict[str, Any] = Field(default_factory=dict)

    def to_dataclass(self) -> DomainConfig:
        return DomainConfig(
            name=self.name,
            enabled=self.enabled,
            tags=list(self.tags),
            inputs={key: value.to_dataclass() for key, value in self.inputs.items()},
            outputs={key: value.to_dataclass() for key, value in self.outputs.items()},
            params=dict(self.params),
        )


class LoggingConfigModel(BaseModel):
    """Pydantic model for logging validation."""

    model_config = ConfigDict(extra="forbid")

    level: str = "INFO"
    log_dir: str = "logs"
    to_console: bool = True
    to_file: bool = True

    def to_dataclass(self) -> LoggingConfig:
        return LoggingConfig(
            level=self.level,
            log_dir=self.log_dir,
            to_console=self.to_console,
            to_file=self.to_file,
        )


class GlobalConfigModel(BaseModel):
    """Pydantic model for top-level config validation."""

    model_config = ConfigDict(extra="ignore")

    env: str
    logging: LoggingConfigModel
    active_domains: list[str] = Field(default_factory=list)
    active_tags: list[str] = Field(default_factory=list)
    domains: dict[str, DomainConfigModel] = Field(default_factory=dict)

    def to_dataclass(self) -> GlobalConfig:
        return GlobalConfig(
            env=self.env,
            logging=self.logging.to_dataclass(),
            active_domains=list(self.active_domains),
            active_tags=list(self.active_tags),
            domains={key: value.to_dataclass() for key, value in self.domains.items()},
        )
