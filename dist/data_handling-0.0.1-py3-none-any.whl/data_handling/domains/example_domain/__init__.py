"""Example domain pipeline."""

__all__ = []
