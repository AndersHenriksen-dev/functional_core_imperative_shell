"""Pipeline composition for the example domain."""

from __future__ import annotations

from data_handling.core import read_dataframe, write_dataframe
from data_handling.core.logging import get_domain_logger
from data_handling.domains.example_domain.ops import compute_metrics, compute_scores
from data_handling.schema.types import DomainConfig


def run(cfg: DomainConfig) -> None:
    logger = get_domain_logger(__name__, cfg.name)

    customers = read_dataframe(cfg.inputs["customers"])
    transactions = read_dataframe(cfg.inputs["transactions"])

    threshold = float(cfg.params.get("score_threshold", 0.7))
    scores = compute_scores(customers, transactions, threshold)
    metrics = compute_metrics(scores)

    write_dataframe(scores, cfg.outputs["scores"])
    write_dataframe(metrics, cfg.outputs["metrics"])

    logger.info("Wrote %s scores and %s metrics", len(scores), len(metrics))
