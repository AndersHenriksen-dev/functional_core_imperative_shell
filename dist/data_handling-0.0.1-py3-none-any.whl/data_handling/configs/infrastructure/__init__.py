"""Infrastructure configuration group."""
