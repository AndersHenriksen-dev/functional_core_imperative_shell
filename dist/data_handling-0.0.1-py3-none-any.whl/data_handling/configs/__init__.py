"""Packaged Hydra configurations."""
