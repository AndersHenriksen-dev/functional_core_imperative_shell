"""Domain configuration group."""
